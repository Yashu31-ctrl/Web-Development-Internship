# To-Do List Web Application

A simple and responsive To-Do List application built using HTML, CSS, and JavaScript.

## Features
- Add Tasks
- Delete Tasks
- Mark Tasks as Completed
- Local Storage Support
- Responsive Design

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Author
Yashwanthi