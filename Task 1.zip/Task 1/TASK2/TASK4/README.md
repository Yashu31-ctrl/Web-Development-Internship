# Task 4 - HTML Form

A student registration form created using HTML, CSS, and JavaScript.

## Features

- Name Field
- Email Field
- Phone Number Field
- Gender Selection
- Skills Selection
- Country Dropdown
- Message Box
- Form Validation

## Technologies Used

- HTML5
- CSS3
- JavaScript