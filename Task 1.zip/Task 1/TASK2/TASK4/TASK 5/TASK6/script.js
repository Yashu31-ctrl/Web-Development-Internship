let tasks =
JSON.parse(localStorage.getItem("tasks")) || [];

displayTasks();

function addTask(){

    let taskInput =
    document.getElementById("taskInput");

    let taskText =
    taskInput.value.trim();

    if(taskText === ""){
        alert("Please enter a task");
        return;
    }

    tasks.push({
        text:taskText,
        completed:false
    });

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );

    taskInput.value = "";

    displayTasks();
}

function displayTasks(){

    let taskList =
    document.getElementById("taskList");

    taskList.innerHTML = "";

    tasks.forEach((task,index)=>{

        taskList.innerHTML += `
        <li class="${task.completed ? 'completed' : ''}">
            ${task.text}

            <div class="actions">

                <button onclick="toggleTask(${index})">
                    ✔
                </button>

                <button onclick="deleteTask(${index})">
                    ✖
                </button>

            </div>
        </li>
        `;
    });
}

function toggleTask(index){

    tasks[index].completed =
    !tasks[index].completed;

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );

    displayTasks();
}

function deleteTask(index){

    tasks.splice(index,1);

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );

    displayTasks();
}