# Task 5 - Blogging Platform

A simple blogging platform built using HTML, CSS, and JavaScript.

## Features

- Create Blog Posts
- Display Blog Posts
- Delete Blog Posts
- Local Storage Support
- Responsive Design

## Technologies Used

- HTML5
- CSS3
- JavaScript