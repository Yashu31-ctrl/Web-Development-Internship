let blogs =
JSON.parse(localStorage.getItem("blogs")) || [];

displayBlogs();

function addBlog(){

    let title =
    document.getElementById("title").value;

    let content =
    document.getElementById("content").value;

    if(title === "" || content === ""){
        alert("Please fill all fields");
        return;
    }

    let blog = {
        title:title,
        content:content
    };

    blogs.push(blog);

    localStorage.setItem(
        "blogs",
        JSON.stringify(blogs)
    );

    document.getElementById("title").value="";
    document.getElementById("content").value="";

    displayBlogs();
}

function displayBlogs(){

    let blogList =
    document.getElementById("blogList");

    blogList.innerHTML="";

    blogs.forEach((blog,index)=>{

        blogList.innerHTML += `
        <div class="blog">

            <h2>${blog.title}</h2>

            <p>${blog.content}</p>

            <button
            class="delete-btn"
            onclick="deleteBlog(${index})">
            Delete
            </button>

        </div>
        `;
    });
}

function deleteBlog(index){

    blogs.splice(index,1);

    localStorage.setItem(
        "blogs",
        JSON.stringify(blogs)
    );

    displayBlogs();
}