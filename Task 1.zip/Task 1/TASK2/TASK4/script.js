document.getElementById("myForm")
.addEventListener("submit", function(event){

    let name =
    document.getElementById("name").value;

    let email =
    document.getElementById("email").value;

    let phone =
    document.getElementById("phone").value;

    if(name === ""){
        alert("Please enter your name");
        event.preventDefault();
        return;
    }

    if(email === ""){
        alert("Please enter your email");
        event.preventDefault();
        return;
    }

    if(phone === ""){
        alert("Please enter your phone number");
        event.preventDefault();
        return;
    }

    alert("Form Submitted Successfully");
});