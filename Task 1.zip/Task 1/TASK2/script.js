const taskList = document.getElementById("taskList");

window.onload = () => {
    loadTasks();
};

function addTask() {

    const input = document.getElementById("taskInput");

    if(input.value === ""){
        alert("Please enter a task");
        return;
    }

    createTask(input.value);

    saveTask(input.value);

    input.value = "";
}

function createTask(taskText){

    const li = document.createElement("li");

    const span = document.createElement("span");
    span.textContent = taskText;

    span.onclick = () => {
        span.classList.toggle("completed");
    };

    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.className = "delete-btn";

    delBtn.onclick = () => {
        li.remove();
        removeTask(taskText);
    };

    li.appendChild(span);
    li.appendChild(delBtn);

    taskList.appendChild(li);
}

function saveTask(task){
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks(){
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    tasks.forEach(task => {
        createTask(task);
    });
}

function removeTask(task){
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    tasks = tasks.filter(t => t !== task);

    localStorage.setItem("tasks", JSON.stringify(tasks));
}